Disclaimer:

- All Leg Inputs that are displayed here are done by the sliding method. The piano method is harder, but is more reliable so practice it when you can.

- Look at the Inputs if you are confused about what button to press or dont understand the notation

- Execute the COmbos as close as possible to the opponent as possible to ensure that it works. Stand reasonably far for Jumpins

- Some combos are charachter specific or corner only. This is specified in the description

Have fun and train hard

The_book_dude

Write me on reddit for requests and critique :)