Disclaimer:

-Always stand as close as possible, as not to mess with the dashpunch traveltime.

- Exception: Some combos are timed to be done after "restart" has been pressed and the activated. You can identify these when the charachter walks forward at the start of the round.

- All meaty combos requre you to turn the blocking from "all block" to "no block", so that the dummy doesnt block on wakeup. Be sure to set it back after

-All Charachter specific combos are described as such on the cobmo description

-Most of the time the Dashpunches to end a combo are interchangeable

-Look at the inputs if you are unsure about a button

-The trial combos are meant to be played as soon as the "fight" on the screen is gone, no placement required



Hope this helps, and i wish you a lot of fun training.

For request and critique send me a message on reddit The_Book_dude,

Cheers