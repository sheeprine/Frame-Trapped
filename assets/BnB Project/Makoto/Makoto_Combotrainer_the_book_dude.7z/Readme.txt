Disclaimer:

-ExHayate can replace any Hayate to end a Combo

-ExOverhead can combos from st.mp and st.hp, you replace it as a combo ender

-Stand as near as possible when beginning the Combotrainer replays, stand in jump range when nessesary for the Combo

Have Fun and train hard :)

Message me when you have requests or critique at the_book_dude on reddit

gl hf