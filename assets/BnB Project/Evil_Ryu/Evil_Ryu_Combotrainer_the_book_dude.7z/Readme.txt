Disclaimer:

- Look at the Inputs if you are confused about what button to press or dont understand the notation

- Execute the Combos as close as possible to the opponent as possible to ensure that it works.

- Some combos are charachter specific or corner only/spacing dependant. This is specified in the description.

Have fun and train hard

The_book_dude

Write me on reddit for requests and critique :)