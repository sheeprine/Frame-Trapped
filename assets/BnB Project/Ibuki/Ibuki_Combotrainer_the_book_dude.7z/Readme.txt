Disclaimer:

- You can almost always replace the Neckbreaker for Uppercut, Raida or Tsumuji. Everyone has its place.

- Look at the Inputs if you are confused about what button to press or dont understand the notation

- Execute the COmbos as close as possible to the opponent as possible to ensure that it works

- Some combos are charachter specific or corner only. This is specified in the descrition

Have fun and train hard

The_book_dude

Write me on reddit for requests and critique :)