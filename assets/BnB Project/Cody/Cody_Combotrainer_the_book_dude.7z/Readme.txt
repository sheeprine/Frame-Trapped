Disclaimer:

-Roundhouse Ruffiankick hits only standing opponents or after a force stand like crouching Hard Punch, be aware of that!

-Most of the time you can chose between Fierce Criminal Upper for Damage oder forward Ruffian Kick for Spacecontrol

-After Roundhouse Ruffiankick you can Fadc Ultra 1

-Look at the Inputs if you are unsure what Button to use

-Stand as close as possible when using the COmbotrainer files, so as not to mess with the timing(Stand at reasonable range for jumpin combos)

Have fun and train hard!

Message me for requests and critique at the_book_dude on reddit.

gl hf