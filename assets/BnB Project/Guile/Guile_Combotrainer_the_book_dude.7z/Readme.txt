A few things:

-Turn on the sounds for Buttons that you would like to hear.

-Most of the time Sonic_boom-Ender can be swapt out for FLashkick Ender and vice versa.

-Look at the Inputs to determine the strenghts of the buttons when not specified.

Pm me on reddit The_book_dude if you have questions or requests/critique.

Have Fun and train hard :)


